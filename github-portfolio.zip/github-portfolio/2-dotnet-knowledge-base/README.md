# .NET Knowledge Base

Biblioteca de conhecimento prático de um desenvolvedor .NET: o que eu uso no dia a dia, com exemplos executáveis e o raciocínio de "quando usar / quando não usar".

*A practical .NET developer's knowledge base: what I use day to day, with runnable examples and "when to use / when not to" reasoning.*

## 📚 Índice / Index

| Área | Conteúdo | Status |
|---|---|---|
| [01-fundamentos](./01-fundamentos) | C#, LINQ, async/await, injeção de dependência | 🚧 |
| [02-web](./02-web) | MVC, API REST, autenticação, middlewares | 🚧 |
| [03-dados](./03-dados) | EF Core, Dapper, MySQL, índices, queries lentas | 🚧 |
| [04-desempenho](./04-desempenho) | Refatorações antes/depois, profiling, cache | 🚧 |
| [05-testes](./05-testes) | xUnit, mocks, testes de integração | 🚧 |
| [06-arquitetura](./06-arquitetura) | Camadas, SOLID, padrões, Clean Architecture | 🚧 |
| [snippets](./snippets) | Trechos reutilizáveis com exemplo | 🚧 |

### Tópicos publicados / Published topics

- [N+1 queries no EF Core](./03-dados/n-mais-1-queries.md)

## 🧭 Como cada tópico é escrito

Todo tópico segue o [template](./TEMPLATE-topico.md): problema, solução, código, quando usar, quando evitar, e um exemplo que roda com `dotnet run` ou `dotnet test`.

## ▶️ Rodando os exemplos

```bash
git clone https://github.com/SEU-USUARIO/dotnet-knowledge-base.git
cd dotnet-knowledge-base/<area>/<topico>/exemplo
dotnet run
```

## 🤝 Contribuições

Correções e sugestões são bem-vindas via issue ou pull request.

## 📄 Licença

MIT
