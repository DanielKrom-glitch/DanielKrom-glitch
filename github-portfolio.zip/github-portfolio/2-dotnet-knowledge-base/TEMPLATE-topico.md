# Título do tópico

> **Nível:** básico | intermediário | avançado  
> **Área:** fundamentos | web | dados | desempenho | testes | arquitetura  
> **Versão testada:** .NET 8 (ajuste para a que você usou)

## O problema

Em 2 ou 3 frases: que situação real leva a este tópico? Em que momento isso dói no dia a dia?

## A solução

Explique a ideia central em linguagem simples, sem despejar documentação.

## Exemplo

### ❌ Antes

```csharp
// código com o problema
```

### ✅ Depois

```csharp
// código corrigido
```

Exemplo executável: [`./exemplo`](./exemplo) (`dotnet run` ou `dotnet test`).

## Quando usar

- 

## Quando evitar

- 

## Armadilhas comuns

- 

## Para ir além

- Link da documentação oficial
- Tópicos relacionados neste repositório
