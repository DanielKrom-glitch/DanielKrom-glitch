# N+1 queries no EF Core

> **Nível:** intermediário  
> **Área:** dados  
> **Versão testada:** .NET 8 + EF Core 8

## O problema

Uma tela lista 100 clientes e, para cada um, mostra seus agendamentos. O código parece inocente, mas gera **1 query para os clientes + 100 queries para os agendamentos**. Com mais dados, a tela fica lenta e o banco sofre.

## A solução

Carregar os dados relacionados na mesma consulta (`Include`) ou projetar só o que a tela precisa (`Select`), em vez de deixar cada acesso à propriedade virar uma ida ao banco.

## Exemplo

### ❌ Antes

```csharp
var clientes = await db.Clientes.ToListAsync();

foreach (var c in clientes)
{
    // Com lazy loading (ou consultas dentro do loop), cada iteração vai ao banco
    var total = await db.Agendamentos.CountAsync(a => a.ClienteId == c.Id);
    Console.WriteLine($"{c.Nome}: {total}");
}
```

### ✅ Depois (projeção, a melhor opção quando você só precisa de números)

```csharp
var resumo = await db.Clientes
    .Select(c => new
    {
        c.Nome,
        Total = c.Agendamentos.Count
    })
    .ToListAsync();
```

### ✅ Depois (quando precisa das entidades relacionadas)

```csharp
var clientes = await db.Clientes
    .Include(c => c.Agendamentos)
    .AsSplitQuery() // evita explosão cartesiana em coleções grandes
    .ToListAsync();
```

## Como detectar

- Habilite o log de SQL: `optionsBuilder.LogTo(Console.WriteLine, LogLevel.Information)`.
- Se a mesma query aparece dezenas de vezes mudando só o parâmetro, é N+1.
- Use também um profiler (MiniProfiler, logs do MySQL com `general_log` em ambiente de dev).

## Quando usar cada abordagem

- **`Select` (projeção):** telas e relatórios que precisam de poucos campos. Normalmente a mais rápida.
- **`Include`:** quando você realmente vai usar as entidades relacionadas.
- **`AsSplitQuery`:** `Include` com coleções grandes, para evitar linhas duplicadas no resultado.

## Quando evitar

- `Include` em tudo "por garantia": traz dados que ninguém usa.
- `AsNoTracking()` está ausente em consultas de leitura: acrescente quando não for alterar as entidades.

## Armadilhas comuns

- Lazy loading ligado sem perceber, escondendo o N+1.
- Chamar `ToList()` cedo demais e filtrar em memória.

## Para ir além

- Documentação oficial do EF Core: *Loading Related Data* e *Efficient Querying*.
