# NOME-DO-PROJETO

![build](https://github.com/SEU-USUARIO/NOME-DO-PROJETO/actions/workflows/dotnet.yml/badge.svg)

Uma frase dizendo o que o projeto faz e para quem.

*One sentence on what the project does and who it is for.*

## 🎯 Problema que resolve

2 a 3 frases sobre o cenário real. Ex.: "Gerenciar agendamentos evitando conflitos de horário entre profissionais."

## ✨ Funcionalidades

- Autenticação com JWT
- CRUD de ...
- Regras de negócio: ...
- Testes automatizados (unitários e de integração)

## 🧱 Arquitetura

Descreva as camadas e as decisões. Se possível, inclua um diagrama simples.

```
src/
├── Api/             controllers, middlewares, configuração
├── Application/     casos de uso, DTOs, validações
├── Domain/          entidades e regras de negócio
└── Infrastructure/  acesso a dados (MySQL), serviços externos
tests/
```

**Decisões e porquês:** por que essas camadas, por que Dapper ou EF Core, como trata erros, etc.

## 🛠️ Tecnologias

.NET · C# · MySQL · JWT · xUnit · Docker · GitHub Actions

## ▶️ Como rodar

```bash
git clone https://github.com/SEU-USUARIO/NOME-DO-PROJETO.git
cd NOME-DO-PROJETO
docker compose up --build
```

API em `http://localhost:8080` · Swagger em `http://localhost:8080/swagger`

## 🧪 Testes

```bash
dotnet test
```

## 📸 Screenshots

Insira imagens do Swagger ou da interface.

## 🗺️ Próximos passos

- [ ] 
- [ ] 

## 📄 Licença

MIT
