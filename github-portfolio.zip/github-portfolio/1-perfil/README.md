<!-- Este arquivo vai em um repositório PÚBLICO chamado exatamente como seu usuário: SEU-USUARIO/SEU-USUARIO -->

# Olá, eu sou o Daniel 👋

**Desenvolvedor fullstack .NET** com 5 anos de experiência construindo e otimizando sistemas web: agendamento, APIs REST e refatoração para ganho de desempenho.

**Fullstack .NET developer** with 5 years of experience building and optimizing web systems: scheduling, REST APIs and performance-focused refactoring.

---

## 🛠️ Stack

![C#](https://img.shields.io/badge/C%23-239120?style=flat&logo=csharp&logoColor=white)
![.NET](https://img.shields.io/badge/.NET-512BD4?style=flat&logo=dotnet&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-4479A1?style=flat&logo=mysql&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=flat&logo=javascript&logoColor=black)
![jQuery](https://img.shields.io/badge/jQuery-0769AD?style=flat&logo=jquery&logoColor=white)
![Docker](https://img.shields.io/badge/Docker-2496ED?style=flat&logo=docker&logoColor=white)
![Git](https://img.shields.io/badge/Git-F05032?style=flat&logo=git&logoColor=white)

.NET MVC · API REST · MySQL · JavaScript · jQuery

## 📌 Projetos em destaque / Featured

| Projeto | Descrição / Description |
|---|---|
| [dotnet-knowledge-base](https://github.com/SEU-USUARIO/dotnet-knowledge-base) | Biblioteca de conhecimento prático de .NET: conceitos, exemplos executáveis e casos de desempenho. / Practical .NET knowledge base. |
| [NOME-DO-PROJETO-API](https://github.com/SEU-USUARIO/NOME-DO-PROJETO-API) | API REST em .NET com JWT, MySQL, testes e Docker. / .NET REST API with JWT, MySQL, tests and Docker. |

## 🎓 Formação / Education

Sistemas de Informação, Universidade do Oeste Paulista (Unoeste), formatura prevista para 2027.

## 📫 Contato / Contact

- LinkedIn: [SEU-LINKEDIN](https://www.linkedin.com/in/SEU-LINKEDIN)
- E-mail: SEU-EMAIL

> Aberto a oportunidades de nível pleno/sênior. / Open to mid/senior-level opportunities.
